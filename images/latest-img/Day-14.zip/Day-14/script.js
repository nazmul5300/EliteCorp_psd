
//------------------------
 // For Bangla Frist Pepar
 //-----------------------
function result1(){
	var _tm=parseInt(document.getElementById('tm').value);
	var _pm=parseInt(document.getElementById('pm').value);
	if (_tm <=0 && _pm <=0 || document.getElementById('tm').value=="" && document.getElementById('pm').value) {
		alert("Please Enter Mark First");
		document.getElementById('ttm').value=0;
	}
	else{
		var _totalMark=_tm+_pm;
		document.getElementById('ttm').value=_totalMark;
		
		if (_totalMark >= 80 && _totalMark <=100) {
			document.getElementById('grad').value="A+";
			document.getElementById('point').value="5.00";
		}
		else if (_totalMark >= 70 && _totalMark <=79) {
			document.getElementById('grad').value="A";
			document.getElementById('point').value="4.00";
		}
		else if (_totalMark >= 60 && _totalMark <=69) {
			document.getElementById('grad').value="A-";
			document.getElementById('point').value="3.50";
		}
		else if (_totalMark >= 50 && _totalMark <=59) {
			document.getElementById('grad').value="B";
			document.getElementById('point').value="3.00";
		}
		else if (_totalMark >= 40 && _totalMark <=49) {
			document.getElementById('grad').value="C";
			document.getElementById('point').value="2.00";
		}
		else if (_totalMark >= 33 && _totalMark <=39) {
			document.getElementById('grad').value="D";
			document.getElementById('point').value="1.00";
		}
		else if (_totalMark >= 0 && _totalMark <=32) {
			document.getElementById('grad').value="F";
			document.getElementById('point').value="0.00";
		}
		else{
			alert("Invalid Input");
			document.getElementById('grad').value="";
			document.getElementById('point').value="";
			document.getElementById('tm').value="";
			document.getElementById('pm').value="";
			document.getElementById('ttm').value="";
		}
	}
}

//------------------------
 // For Bangla Frist Pepar
 //-----------------------
function result2(){
	var _tm=parseInt(document.getElementById('tm1').value);
	var _pm=parseInt(document.getElementById('pm1').value);
	if (_tm <=0 && _pm <=0 || document.getElementById('tm1').value=="" && document.getElementById('pm1').value) {
		alert("Please Enter Mark First");
		document.getElementById('ttm1').value=0;
	}
	else{
		var _totalMark=_tm + _pm;
		document.getElementById('ttm1').value=_totalMark;
		
		if (_totalMark >= 80 && _totalMark <=100) {
			document.getElementById('grad1').value="A+";
			document.getElementById('point1').value="5.00";
		}
		else if (_totalMark >= 70 && _totalMark <=79) {
			document.getElementById('grad1').value="A";
			document.getElementById('point1').value="4.00";
		}
		else if (_totalMark >= 60 && _totalMark <=69) {
			document.getElementById('grad1').value="A-";
			document.getElementById('point1').value="3.50";
		}
		else if (_totalMark >= 50 && _totalMark <=59) {
			document.getElementById('grad1').value="B";
			document.getElementById('point1').value="3.00";
		}
		else if (_totalMark >= 40 && _totalMark <=49) {
			document.getElementById('grad1').value="C";
			document.getElementById('point1').value="2.00";
		}
		else if (_totalMark >= 33 && _totalMark <=39) {
			document.getElementById('grad1').value="D";
			document.getElementById('point1').value="1.00";
		}
		else if (_totalMark >= 0 && _totalMark <=32) {
			document.getElementById('grad1').value="F";
			document.getElementById('point1').value="0.00";
		}
		else{
			alert("Invalid Input");
			document.getElementById('grad1').value="";
			document.getElementById('point1').value="";
			document.getElementById('tm1').value="";
			document.getElementById('pm1').value="";
			document.getElementById('ttm1').value="";
		}
	}
}

 //------------------------
 // For English 1st Pepar
 //------------------------
function result3(){
	var _tm=parseInt(document.getElementById('tm2').value);
	var _pm=parseInt(document.getElementById('pm2').value);
	if (_tm <=0 && _pm <=0 || document.getElementById('tm2').value=="" && document.getElementById('pm2').value) {
		alert("Please Enter Mark First");
		document.getElementById('ttm2').value=0;
	}
	else{
		var _totalMark=_tm+_pm;
		document.getElementById('ttm2').value=_totalMark;
		
		if (_totalMark >= 80 && _totalMark <=100) {
			document.getElementById('grad2').value="A+";
			document.getElementById('point2').value="5.00";
		}
		else if (_totalMark >= 70 && _totalMark <=79) {
			document.getElementById('grad2').value="A";
			document.getElementById('point2').value="4.00";
		}
		else if (_totalMark >= 60 && _totalMark <=69) {
			document.getElementById('grad2').value="A-";
			document.getElementById('point2').value="3.50";
		}
		else if (_totalMark >= 50 && _totalMark <=59) {
			document.getElementById('grad2').value="B";
			document.getElementById('point2').value="3.00";
		}
		else if (_totalMark >= 40 && _totalMark <=49) {
			document.getElementById('grad2').value="C";
			document.getElementById('point2').value="2.00";
		}
		else if (_totalMark >= 33 && _totalMark <=39) {
			document.getElementById('grad2').value="D";
			document.getElementById('point2').value="1.00";
		}
		else if (_totalMark >= 0 && _totalMark <=32) {
			document.getElementById('grad2').value="F";
			document.getElementById('point2').value="0.00";
		}
		else{
			alert("Invalid Input");
			document.getElementById('grad2').value="";
			document.getElementById('point2').value="";
			document.getElementById('tm2').value="";
			document.getElementById('pm2').value="";
			document.getElementById('ttm2').value="";
		}
	}
}

// final result
function finalResult(){
	
	if(document.getElementById("grad").value=="F" || document.getElementById("grad1").value=="F" || document.getElementById("grad2").value=="F")
	{

		document.getElementById("totalgrade").value="F";
		document.getElementById("totalPoint").value="0.00";
		document.getElementById("totalMark").value="0.00";
	}
	else{
		var _tm=document.getElementById('ttm').value;
		var _tm1=document.getElementById('ttm1').value;
		var _tm2=document.getElementById('ttm2').value;
		var _totalMark = parseInt(_tm)+parseInt(_tm1)+parseInt(_tm2);
		document.getElementById('totalMark').value=_totalMark;

		var _point =document.getElementById('point').value;
		var _point1 =document.getElementById('point1').value;
		var _point2 =document.getElementById('point2').value;
		var _totalPoint=((parseFloat(_point) + parseFloat(_point1) +parseFloat(_point2))/3);

		document.getElementById("totalPoint").value=_totalPoint;

		if (_totalPoint==5.00) {
			document.getElementById("totalgrade").value="A+";
		}
		else if(_totalPoint >= 4.00 && _totalPoint<=4.99){
			document.getElementById("totalgrade").value="A";
		}
		else if(_totalPoint >= 3.00 && _totalPoint<=3.99){
			document.getElementById("totalgrade").value="A-";
		}
		else if(_totalPoint >= 2.00 && _totalPoint<=2.99){
			document.getElementById("totalgrade").value="A-";
		}
		else if(_totalPoint >= 1.00 && _totalPoint<=1.99){
			document.getElementById("totalgrade").value="A-";
		}
	}
}






